from veron_nepveux_project.main import app

app(prog_name="Estimateur")
