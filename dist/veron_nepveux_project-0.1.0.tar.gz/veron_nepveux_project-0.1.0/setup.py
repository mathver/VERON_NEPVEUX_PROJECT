# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['veron_nepveux_project']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0',
 'numpy>=1.24.1,<2.0.0',
 'pandas>=1.5.2,<2.0.0',
 'pyqt6>=6.4.0,<7.0.0',
 'pyserde>=0.9.7,<0.10.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'qt-material>=2.12,<3.0',
 'rich>=13.0.1,<14.0.0',
 'scikit-learn>=1.2.0,<2.0.0',
 'seaborn>=0.12.2,<0.13.0',
 'selenium>=4.7.2,<5.0.0',
 'serde>=0.9.0,<0.10.0',
 'typer>=0.7.0,<0.8.0',
 'webdriver-manager>=3.8.5,<4.0.0']

setup_kwargs = {
    'name': 'veron-nepveux-project',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Projet Machine Learning\n\nL'objectif de ce projet est de créer un modèle basé sur des techniques de machine learning pour prédire le prix d'un véhicule choisi par l'utilisateur à partir de ces caractéristiques. Le modèle étant entraîné sur une bases de données.\n\nLe programme est divisé en deux grandes parties :\n\n- Scraping\n- Estimation\n\n---\n## Scraping\n\n### **Données**\n\nLe site d'origine des données est le site [Spoticar](https://www.spoticar.fr). \n\nElles concernent quatre marques sur lesquelles le site est spécialisé :\n\n- Peugeot\n- Citroën\n- Opel\n- Fiat\n\nPour chaque marque, nous pouvons récupérer 600 données (soit un total de 2400) de par la construction du site qui nous impose cette contrainte.\n\nChaque véhicule est ainsi codé sous la forme d'une classe `Voiture` comprennant les éléments suivants :\n\n| Variable   |      Type      | Description    |\n|:-|:-|:-|\n| `marque` |Catégorielle| Marque du véhicule| \n| `modele` |Catégorielle| Nom du modèle de véhicule| \n| `carburant` |Catégorielle| Type de carburant ou d'alimentation | \n| `prix` |Numérique| Prix du véhicule sur le site|\n| `kilometrage` |Numérique| Kilométrage du véhicule |\n| `garantie_kilometrage` |Dichotomique| Indicateur de fiabilité concernant la valeur du kilométrage |\n| `boite_de_vitesse` |Catégorielle| Type de boîte de vitesse |\n| `transmission` |Numérique| Nombre de roues motrices | \n| `couleur` |Catégorielle| Couleur du véhicule | \n|  `garantie` |Dichotomique| Type de garantie proposé par le site vendeur | \n| `date_mise_circulation` |Numérique| Année de mise en  circulation du véhicule| \n| `puissance` |Numérique| Puissance du moteur(en cv) |\n| `silhouette` |Catégorielle| Type de véhicule | \n| `nb_places` |Numérique| Nombre de places | \n| `utilisation_pred` |Catégorielle| Précédente utilisation/propriétaire du véhicule | \n| `puissance_fiscale` |Numérique| Puissance fiscale du véhicule (en cv) |\n| `critait` |Numérique| Indice Crit'air du véhicule | \n| `ptac` |Numérique| PTAC du véhicule | \n| `nb_portes` |Numérique| Nombre de portes |\n---\n### **Récupération des données**\n\nLe scraping fonctionne à l'aide du module `selenium` et du navigateur Chrome de Google (ainsi que son driver). \n\nLa fonction de scraping s'occupe d'ouvrir la page web, de gérer les cookies et d'ouvrir chaque annonce pour en récupérer les données. Cette fonction s'itère pour chaque marque permettant de réinitiliser le driver  à chaque fois et d'éviter une surcharge de ce dernier. \n\nLes temps d'attente ont été minimisés, mais certains restent à l'aide de la fonction `sleep()` pour gérer les différents débit de connexion. \n\nChaque page de véhicule est stockée dans la classe `Voiture` précédemment évoquée et ajouté à une liste. \n\nLorsque les 600 annonces ont été scrapé, la fonction stocke cette liste dans un fichier `json` au nom de la marque permettant la séréalisation de celui-ci.\n\n---\n### **Aperçu des données**\n\n![](output.png)\n\n\nLes deux graphiques permettent de rendre compte de la répartition des prix et du kilométrage dans la base de données compris avec ce projet.\n\nOn y observe des prix centré autour de 20 000 € et des kilométrages décroissant mais plus présent dans des valeurs inférieurs à 40 000 km. Cela s'explique par le type de véhicule vendus par Spoticar.\n\n*NB : les graphiques peuvent changer si le scraping est relancé.*\n\n---\n### **Traitement des données**\n\nAvant tout calcul de modèle, les données doivent subir un traitement permettant leur compatibilité avec le module `scikit-learn`. \n\nIl faut premièrement unifier les données obtenues. Elles sont divisés en quatre fichiers `json` donc le nom est éponyme aux marques. Pour cela, on les ouvre et les concatène à l'aide de la fonction `concat` de `pandas` sous la forme d'un tableau de données (dataframe).\n \nLa seconde étape est la gestion des données manquantes pour lesquelles s'offrent plusieurs solutions :\n\n- Suppression des observations\n    - Le suppression d'observation réduit la taille de la base de données, chose que nous ne pouvons nous permettre de par le faible nombre d'observations. Cela les réduirait d'environ 1/3 et pourrait rendre le modèle faux.\n- Suppression de variables\n    - Presque toutes les variables sont concernées par ce problème, cette solution n'est donc pas viable.\n- Imputation\n    - **C'est la solution que nous avons choisie telle que :**\n        - Les variables numériques sont imputées par la moyenne.\n        - les variables catégorielles et dichotomiques sont imputées par la valeur la plus présente.\n\nUne fois que toutes les données manquantes ont été imputées, il faut transformer les variables catégorielles en variables dichotomiques pour la compatibilité avec les modèles. Pour cela, on utilise la fonction `get_dummies()` de `pandas`.\n\nElle transforme une variable catégorielle en autant de variables dichotomiques qu'il y a de modalités et fais prendre les valeurs 0 et 1 à ces dernières. On se retrouve alors avec un tableau de données comprennant une soixantaine de colonnes.\n\nEnfin, il suffit de transformer ce dataframe final en deux tableau du module `numpy` : \n- L'un contenant les valeurs pour chaque variables.\n- L'autre contenant les prix.\n\nCes deux tableaux finaux sont ceux que l'on utilisera pour calculer les modèles.\n\n---\n\n## Estimation\n### **Modèle utilisés**\n\nLes modèles utilisés sont tous tirés du module `scikit-learn`.\n\nIls comprennent :\n\n- Elastic Net\n- Support Vector Machine\n- Random Forest\n- Multi-Layer Perceptron\n- KNN\n\nLes données sont divisés en deux splits avec un rapport 2/3 ; 1/3  :\n\n1. Entraînement\n2. Test\n\nChaque modèle est entrainé par validation croisée sur le split d'entraînement permettant d'obtenir les paramètres optimaux parmi une liste préselectionnée.\n\nUne fonction permet ensuite de calculer le meilleur estimateur, de vérifier que celui-ci ne fait pas de sur-apprentissage à l'aide des données test et de le sauvegarder dans un fichier au format `pickle`.\n\n*NB : le meilleur modèle est recalculé si le scraping est relancé.*\n\nConcernant l'estimation du prix du véhicule de l'utilisateur, cette partie sera traitée dans la partie interface.\n\n---\n\n## Interface utilisateur\n\nCe projet est composé de deux interfaces différentes. La première offrant le choix à l'utilisateur de lancer le scraping ou d'estimer son véhicule. La seconde découlant de la première permet à l'utilisateur de donner les paramètres de son véhicule.\n\n### **Interface textuelle**\n\nL'interface textuelle a été codée à l'aide du module `typer`. \n\nPour lancer l'interface, il suffit d'exécuter la commande suivante :\n\n```sh\npy -m veron_nepveux_project main.py --help\n```\n\nCette commande permet d'afficher les deux commandes disponibles.\n\nIl est ensuite possible de lancer le scraping :\n\n```sh\npy -m veron_nepveux_project main.py scraping\n```\n\nou l'estimation :\n\n```sh\npy -m veron_nepveux_project main.py estimation\n```\n\nLancer la commande d'estimation abouti à cette interface : \n\n![Inter](interface.png)\n\nLorsque l'utilisateur valide, le modèle précédemment choisi estime le prix prédit de la voiture et le retourne ainsi que le prix d'origine en fournissant la différence de prix entre les deux dans la commande.\n",
    'author': 'Mathieu',
    'author_email': 'mathieuveron@outlook.fr>, Baptiste <baptiste.nepveux@icloud.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
